For information on installing libraries, see: http://www.arduino.cc/en/Guide/Libraries

Microsoft Windows [Version 10.0.10586]
(c) 2015 Microsoft Corporation. All rights reserved.

C:\Users\nursenakarakas\Desktop\cs361\assignment1>python manage.py runserver
Performing system checks...

System check identified no issues (0 silenced).

You have 13 unapplied migration(s). Your project may not work properly until you apply the migrations for app(s): admin, auth, contenttypes, sessions.
Run 'python manage.py migrate' to apply them.
December 15, 2017 - 14:26:28
Django version 1.11, using settings 'assignment1.settings'
Starting development server at http://127.0.0.1:8000/
Quit the server with CTRL-BREAK.

C:\Users\nursenakarakas\Desktop\cs361\assignment1>n
'n' is not recognized as an internal or external command,
operable program or batch file.

C:\Users\nursenakarakas\Desktop\cs361\assignment1>
C:\Users\nursenakarakas\Desktop\cs361\assignment1>
C:\Users\nursenakarakas\Desktop\cs361\assignment1>n
'n' is not recognized as an internal or external command,
operable program or batch file.

C:\Users\nursenakarakas\Desktop\cs361\assignment1>
C:\Users\nursenakarakas\Desktop\cs361\assignment1>n5B5B5B5C5C5C
'n5B5B5B5C5C5C' is not recognized as an internal or external command,
operable program or batch file.

C:\Users\nursenakarakas\Desktop\cs361\assignment1>
C:\Users\nursenakarakas\Desktop\cs361\assignment1>
C:\Users\nursenakarakas\Desktop\cs361\assignment1>
C:\Users\nursenakarakas\Desktop\cs361\assignment1>
C:\Users\nursenakarakas\Desktop\cs361\assignment1>
C:\Users\nursenakarakas\Desktop\cs361\assignment1>
C:\Users\nursenakarakas\Desktop\cs361\assignment1>
C:\Users\nursenakarakas\Desktop\cs361\assignment1>
C:\Users\nursenakarakas\Desktop\cs361\assignment1>
C:\Users\nursenakarakas\Desktop\cs361\assignment1>manage.py startapp app1
'manage.py' is not recognized as an internal or external command,
operable program or batch file.

C:\Users\nursenakarakas\Desktop\cs361\assignment1>manage.py startapp app1
'manage.py' is not recognized as an internal or external command,
operable program or batch file.

C:\Users\nursenakarakas\Desktop\cs361\assignment1>python manage.py startapp app1
python: can't open file 'manage.py': [Errno 2] No such file or directory

C:\Users\nursenakarakas\Desktop\cs361\assignment1>python manage.py startapp app1
python: can't open file 'manage.py': [Errno 2] No such file or directory

C:\Users\nursenakarakas\Desktop\cs361\assignment1>python manage.py startapp app1
python: can't open file 'manage.py': [Errno 2] No such file or directory

C:\Users\nursenakarakas\Desktop\cs361\assignment1>python manage.py startapp app1
python: can't open file 'manage.py': [Errno 2] No such file or directory

C:\Users\nursenakarakas\Desktop\cs361\assignment1>python manage.py startapp app1

C:\Users\nursenakarakas\Desktop\cs361\assignment1>
C:\Users\nursenakarakas\Desktop\cs361\assignment1>
C:\Users\nursenakarakas\Desktop\cs361\assignment1>
C:\Users\nursenakarakas\Desktop\cs361\assignment1>python manage.py makemigrations
Migrations for 'app1':
  app1\migrations\0001_initial.py
    - Create model Car
    - Create model Motor_Capacity

C:\Users\nursenakarakas\Desktop\cs361\assignment1>
C:\Users\nursenakarakas\Desktop\cs361\assignment1>./manage.py createsuperuser
'.' is not recognized as an internal or external command,
operable program or batch file.

C:\Users\nursenakarakas\Desktop\cs361\assignment1>manage.py createsuperuser
Traceback (most recent call last):
  File "C:\Users\nursenakarakas\Desktop\cs361\assignment1\manage.py", line 22, in <module>
    execute_from_command_line(sys.argv)
  File "C:\Python27\lib\site-packages\django\core\management\__init__.py", line 363, in execute_from_command_line
    utility.execute()
  File "C:\Python27\lib\site-packages\django\core\management\__init__.py", line 337, in execute
    django.setup()
  File "C:\Python27\lib\site-packages\django\__init__.py", line 27, in setup
    apps.populate(settings.INSTALLED_APPS)
  File "C:\Python27\lib\site-packages\django\apps\registry.py", line 85, in populate
    app_config = AppConfig.create(entry)
  File "C:\Python27\lib\site-packages\django\apps\config.py", line 127, in create
    import_module(entry)
  File "C:\Python27\lib\importlib\__init__.py", line 37, in import_module
    __import__(name)
ImportError: No module named app1Config

C:\Users\nursenakarakas\Desktop\cs361\assignment1>manage.py createsuperuser

You have 14 unapplied migration(s). Your project may not work properly until you apply the migrations for app(s): admin, app1, auth, contenttypes, sessions.
Run 'python manage.py migrate' to apply them.
Traceback (most recent call last):
  File "C:\Users\nursenakarakas\Desktop\cs361\assignment1\manage.py", line 22, in <module>
    execute_from_command_line(sys.argv)
  File "C:\Python27\lib\site-packages\django\core\management\__init__.py", line 363, in execute_from_command_line
    utility.execute()
  File "C:\Python27\lib\site-packages\django\core\management\__init__.py", line 355, in execute
    self.fetch_command(subcommand).run_from_argv(self.argv)
  File "C:\Python27\lib\site-packages\django\core\management\base.py", line 283, in run_from_argv
    self.execute(*args, **cmd_options)
  File "C:\Python27\lib\site-packages\django\contrib\auth\management\commands\createsuperuser.py", line 63, in execute
    return super(Command, self).execute(*args, **options)
  File "C:\Python27\lib\site-packages\django\core\management\base.py", line 330, in execute
    output = self.handle(*args, **options)
  File "C:\Python27\lib\site-packages\django\contrib\auth\management\commands\createsuperuser.py", line 96, in handle
    default_username = get_default_username()
  File "C:\Python27\lib\site-packages\django\contrib\auth\management\__init__.py", line 148, in get_default_username
    auth_app.User._default_manager.get(username=default_username)
  File "C:\Python27\lib\site-packages\django\db\models\manager.py", line 85, in manager_method
    return getattr(self.get_queryset(), name)(*args, **kwargs)
  File "C:\Python27\lib\site-packages\django\db\models\query.py", line 373, in get
    num = len(clone)
  File "C:\Python27\lib\site-packages\django\db\models\query.py", line 232, in __len__
    self._fetch_all()
  File "C:\Python27\lib\site-packages\django\db\models\query.py", line 1102, in _fetch_all
    self._result_cache = list(self._iterable_class(self))
  File "C:\Python27\lib\site-packages\django\db\models\query.py", line 53, in __iter__
    results = compiler.execute_sql(chunked_fetch=self.chunked_fetch)
  File "C:\Python27\lib\site-packages\django\db\models\sql\compiler.py", line 876, in execute_sql
    cursor.execute(sql, params)
  File "C:\Python27\lib\site-packages\django\db\backends\utils.py", line 80, in execute
    return super(CursorDebugWrapper, self).execute(sql, params)
  File "C:\Python27\lib\site-packages\django\db\backends\utils.py", line 65, in execute
    return self.cursor.execute(sql, params)
  File "C:\Python27\lib\site-packages\django\db\utils.py", line 94, in __exit__
    six.reraise(dj_exc_type, dj_exc_value, traceback)
  File "C:\Python27\lib\site-packages\django\db\backends\utils.py", line 65, in execute
    return self.cursor.execute(sql, params)
  File "C:\Python27\lib\site-packages\django\db\backends\sqlite3\base.py", line 328, in execute
    return Database.Cursor.execute(self, query, params)
django.db.utils.OperationalError: no such table: auth_user

C:\Users\nursenakarakas\Desktop\cs361\assignment1>manage.py createsuperuser

You have 14 unapplied migration(s). Your project may not work properly until you apply the migrations for app(s): admin, app1, auth, contenttypes, sessions.
Run 'python manage.py migrate' to apply them.
Traceback (most recent call last):
  File "C:\Users\nursenakarakas\Desktop\cs361\assignment1\manage.py", line 22, in <module>
    execute_from_command_line(sys.argv)
  File "C:\Python27\lib\site-packages\django\core\management\__init__.py", line 363, in execute_from_command_line
    utility.execute()
  File "C:\Python27\lib\site-packages\django\core\management\__init__.py", line 355, in execute
    self.fetch_command(subcommand).run_from_argv(self.argv)
  File "C:\Python27\lib\site-packages\django\core\management\base.py", line 283, in run_from_argv
    self.execute(*args, **cmd_options)
  File "C:\Python27\lib\site-packages\django\contrib\auth\management\commands\createsuperuser.py", line 63, in execute
    return super(Command, self).execute(*args, **options)
  File "C:\Python27\lib\site-packages\django\core\management\base.py", line 330, in execute
    output = self.handle(*args, **options)
  File "C:\Python27\lib\site-packages\django\contrib\auth\management\commands\createsuperuser.py", line 96, in handle
    default_username = get_default_username()
  File "C:\Python27\lib\site-packages\django\contrib\auth\management\__init__.py", line 148, in get_default_username
    auth_app.User._default_manager.get(username=default_username)
  File "C:\Python27\lib\site-packages\django\db\models\manager.py", line 85, in manager_method
    return getattr(self.get_queryset(), name)(*args, **kwargs)
  File "C:\Python27\lib\site-packages\django\db\models\query.py", line 373, in get
    num = len(clone)
  File "C:\Python27\lib\site-packages\django\db\models\query.py", line 232, in __len__
    self._fetch_all()
  File "C:\Python27\lib\site-packages\django\db\models\query.py", line 1102, in _fetch_all
    self._result_cache = list(self._iterable_class(self))
  File "C:\Python27\lib\site-packages\django\db\models\query.py", line 53, in __iter__
    results = compiler.execute_sql(chunked_fetch=self.chunked_fetch)
  File "C:\Python27\lib\site-packages\django\db\models\sql\compiler.py", line 876, in execute_sql
    cursor.execute(sql, params)
  File "C:\Python27\lib\site-packages\django\db\backends\utils.py", line 80, in execute
    return super(CursorDebugWrapper, self).execute(sql, params)
  File "C:\Python27\lib\site-packages\django\db\backends\utils.py", line 65, in execute
    return self.cursor.execute(sql, params)
  File "C:\Python27\lib\site-packages\django\db\utils.py", line 94, in __exit__
    six.reraise(dj_exc_type, dj_exc_value, traceback)
  File "C:\Python27\lib\site-packages\django\db\backends\utils.py", line 65, in execute
    return self.cursor.execute(sql, params)
  File "C:\Python27\lib\site-packages\django\db\backends\sqlite3\base.py", line 328, in execute
    return Database.Cursor.execute(self, query, params)
django.db.utils.OperationalError: no such table: auth_user

C:\Users\nursenakarakas\Desktop\cs361\assignment1>python manage.py runserver
Performing system checks...

System check identified no issues (0 silenced).

You have 14 unapplied migration(s). Your project may not work properly until you apply the migrations for app(s): admin, app1, auth, contenttypes, sessions.
Run 'python manage.py migrate' to apply them.
December 15, 2017 - 17:10:17
Django version 1.11, using settings 'assignment1.settings'
Starting development server at http://127.0.0.1:8000/
Quit the server with CTRL-BREAK.
[15/Dec/2017 17:10:32] "GET / HTTP/1.1" 200 14
[15/Dec/2017 17:10:39] "GET /admin/ HTTP/1.1" 302 0
[15/Dec/2017 17:10:39] "GET /admin/login/?next=/admin/ HTTP/1.1" 200 1650
Internal Server Error: /admin/login/
Traceback (most recent call last):
  File "C:\Python27\lib\site-packages\django\core\handlers\exception.py", line 41, in inner
    response = get_response(request)
  File "C:\Python27\lib\site-packages\django\core\handlers\base.py", line 187, in _get_response
    response = self.process_exception_by_middleware(e, request)
  File "C:\Python27\lib\site-packages\django\core\handlers\base.py", line 185, in _get_response
    response = wrapped_callback(request, *callback_args, **callback_kwargs)
  File "C:\Python27\lib\site-packages\django\views\decorators\cache.py", line 57, in _wrapped_view_func
    response = view_func(request, *args, **kwargs)
  File "C:\Python27\lib\site-packages\django\contrib\admin\sites.py", line 393, in login
    return LoginView.as_view(**defaults)(request)
  File "C:\Python27\lib\site-packages\django\views\generic\base.py", line 68, in view
    return self.dispatch(request, *args, **kwargs)
  File "C:\Python27\lib\site-packages\django\utils\decorators.py", line 67, in _wrapper
    return bound_func(*args, **kwargs)
  File "C:\Python27\lib\site-packages\django\views\decorators\debug.py", line 76, in sensitive_post_parameters_wrapper
    return view(request, *args, **kwargs)
  File "C:\Python27\lib\site-packages\django\utils\decorators.py", line 63, in bound_func
    return func.__get__(self, type(self))(*args2, **kwargs2)
  File "C:\Python27\lib\site-packages\django\utils\decorators.py", line 67, in _wrapper
    return bound_func(*args, **kwargs)
  File "C:\Python27\lib\site-packages\django\utils\decorators.py", line 149, in _wrapped_view
    response = view_func(request, *args, **kwargs)
  File "C:\Python27\lib\site-packages\django\utils\decorators.py", line 63, in bound_func
    return func.__get__(self, type(self))(*args2, **kwargs2)
  File "C:\Python27\lib\site-packages\django\utils\decorators.py", line 67, in _wrapper
    return bound_func(*args, **kwargs)
  File "C:\Python27\lib\site-packages\django\views\decorators\cache.py", line 57, in _wrapped_view_func
    response = view_func(request, *args, **kwargs)
  File "C:\Python27\lib\site-packages\django\utils\decorators.py", line 63, in bound_func
    return func.__get__(self, type(self))(*args2, **kwargs2)
  File "C:\Python27\lib\site-packages\django\contrib\auth\views.py", line 90, in dispatch
    return super(LoginView, self).dispatch(request, *args, **kwargs)
  File "C:\Python27\lib\site-packages\django\views\generic\base.py", line 88, in dispatch
    return handler(request, *args, **kwargs)
  File "C:\Python27\lib\site-packages\django\views\generic\edit.py", line 182, in post
    if form.is_valid():
  File "C:\Python27\lib\site-packages\django\forms\forms.py", line 183, in is_valid
    return self.is_bound and not self.errors
  File "C:\Python27\lib\site-packages\django\forms\forms.py", line 175, in errors
    self.full_clean()
  File "C:\Python27\lib\site-packages\django\forms\forms.py", line 385, in full_clean
    self._clean_form()
  File "C:\Python27\lib\site-packages\django\forms\forms.py", line 412, in _clean_form
    cleaned_data = self.clean()
  File "C:\Python27\lib\site-packages\django\contrib\auth\forms.py", line 187, in clean
    self.user_cache = authenticate(self.request, username=username, password=password)
  File "C:\Python27\lib\site-packages\django\contrib\auth\__init__.py", line 100, in authenticate
    user = backend.authenticate(*args, **credentials)
  File "C:\Python27\lib\site-packages\django\contrib\auth\backends.py", line 18, in authenticate
    user = UserModel._default_manager.get_by_natural_key(username)
  File "C:\Python27\lib\site-packages\django\contrib\auth\base_user.py", line 48, in get_by_natural_key
    return self.get(**{self.model.USERNAME_FIELD: username})
  File "C:\Python27\lib\site-packages\django\db\models\manager.py", line 85, in manager_method
    return getattr(self.get_queryset(), name)(*args, **kwargs)
  File "C:\Python27\lib\site-packages\django\db\models\query.py", line 373, in get
    num = len(clone)
  File "C:\Python27\lib\site-packages\django\db\models\query.py", line 232, in __len__
    self._fetch_all()
  File "C:\Python27\lib\site-packages\django\db\models\query.py", line 1102, in _fetch_all
    self._result_cache = list(self._iterable_class(self))
  File "C:\Python27\lib\site-packages\django\db\models\query.py", line 53, in __iter__
    results = compiler.execute_sql(chunked_fetch=self.chunked_fetch)
  File "C:\Python27\lib\site-packages\django\db\models\sql\compiler.py", line 876, in execute_sql
    cursor.execute(sql, params)
  File "C:\Python27\lib\site-packages\django\db\backends\utils.py", line 80, in execute
    return super(CursorDebugWrapper, self).execute(sql, params)
  File "C:\Python27\lib\site-packages\django\db\backends\utils.py", line 65, in execute
    return self.cursor.execute(sql, params)
  File "C:\Python27\lib\site-packages\django\db\utils.py", line 94, in __exit__
    six.reraise(dj_exc_type, dj_exc_value, traceback)
  File "C:\Python27\lib\site-packages\django\db\backends\utils.py", line 65, in execute
    return self.cursor.execute(sql, params)
  File "C:\Python27\lib\site-packages\django\db\backends\sqlite3\base.py", line 328, in execute
    return Database.Cursor.execute(self, query, params)
OperationalError: no such table: auth_user
[15/Dec/2017 17:10:49] "POST /admin/login/?next=/admin/ HTTP/1.1" 500 206778
Performing system checks...

Unhandled exception in thread started by <function wrapper at 0x03B19E30>
Traceback (most recent call last):
  File "C:\Python27\lib\site-packages\django\utils\autoreload.py", line 227, in wrapper
    fn(*args, **kwargs)
  File "C:\Python27\lib\site-packages\django\core\management\commands\runserver.py", line 125, in inner_run
    self.check(display_num_errors=True)
  File "C:\Python27\lib\site-packages\django\core\management\base.py", line 359, in check
    include_deployment_checks=include_deployment_checks,
  File "C:\Python27\lib\site-packages\django\core\management\base.py", line 346, in _run_checks
    return checks.run_checks(**kwargs)
  File "C:\Python27\lib\site-packages\django\core\checks\registry.py", line 81, in run_checks
    new_errors = check(app_configs=app_configs)
  File "C:\Python27\lib\site-packages\django\core\checks\urls.py", line 16, in check_url_config
    return check_resolver(resolver)
  File "C:\Python27\lib\site-packages\django\core\checks\urls.py", line 26, in check_resolver
    return check_method()
  File "C:\Python27\lib\site-packages\django\urls\resolvers.py", line 254, in check
    for pattern in self.url_patterns:
  File "C:\Python27\lib\site-packages\django\utils\functional.py", line 35, in __get__
    res = instance.__dict__[self.name] = self.func(instance)
  File "C:\Python27\lib\site-packages\django\urls\resolvers.py", line 405, in url_patterns
    patterns = getattr(self.urlconf_module, "urlpatterns", self.urlconf_module)
  File "C:\Python27\lib\site-packages\django\utils\functional.py", line 35, in __get__
    res = instance.__dict__[self.name] = self.func(instance)
  File "C:\Python27\lib\site-packages\django\urls\resolvers.py", line 398, in urlconf_module
    return import_module(self.urlconf_name)
  File "C:\Python27\lib\importlib\__init__.py", line 37, in import_module
    __import__(name)
  File "C:\Users\nursenakarakas\Desktop\cs361\assignment1\assignment1\urls.py", line 23, in <module>
    url(r"^(?P<car_id>[0-9]+)/$", views.car_details, name='details'),
AttributeError: 'module' object has no attribute 'car_details'
Performing system checks...

Unhandled exception in thread started by <function wrapper at 0x04409E30>
Traceback (most recent call last):
  File "C:\Python27\lib\site-packages\django\utils\autoreload.py", line 227, in wrapper
    fn(*args, **kwargs)
  File "C:\Python27\lib\site-packages\django\core\management\commands\runserver.py", line 125, in inner_run
    self.check(display_num_errors=True)
  File "C:\Python27\lib\site-packages\django\core\management\base.py", line 359, in check
    include_deployment_checks=include_deployment_checks,
  File "C:\Python27\lib\site-packages\django\core\management\base.py", line 346, in _run_checks
    return checks.run_checks(**kwargs)
  File "C:\Python27\lib\site-packages\django\core\checks\registry.py", line 81, in run_checks
    new_errors = check(app_configs=app_configs)
  File "C:\Python27\lib\site-packages\django\core\checks\urls.py", line 16, in check_url_config
    return check_resolver(resolver)
  File "C:\Python27\lib\site-packages\django\core\checks\urls.py", line 26, in check_resolver
    return check_method()
  File "C:\Python27\lib\site-packages\django\urls\resolvers.py", line 254, in check
    for pattern in self.url_patterns:
  File "C:\Python27\lib\site-packages\django\utils\functional.py", line 35, in __get__
    res = instance.__dict__[self.name] = self.func(instance)
  File "C:\Python27\lib\site-packages\django\urls\resolvers.py", line 405, in url_patterns
    patterns = getattr(self.urlconf_module, "urlpatterns", self.urlconf_module)
  File "C:\Python27\lib\site-packages\django\utils\functional.py", line 35, in __get__
    res = instance.__dict__[self.name] = self.func(instance)
  File "C:\Python27\lib\site-packages\django\urls\resolvers.py", line 398, in urlconf_module
    return import_module(self.urlconf_name)
  File "C:\Python27\lib\importlib\__init__.py", line 37, in import_module
    __import__(name)
  File "C:\Users\nursenakarakas\Desktop\cs361\assignment1\assignment1\urls.py", line 23, in <module>
    url(r"^(?P<car_id>[0-9]+)/$", views.car_details, name='details'),
AttributeError: 'module' object has no attribute 'car_details'
Performing system checks...

System check identified no issues (0 silenced).

You have 14 unapplied migration(s). Your project may not work properly until you apply the migrations for app(s): admin, app1, auth, contenttypes, sessions.
Run 'python manage.py migrate' to apply them.
December 15, 2017 - 17:23:43
Django version 1.11, using settings 'assignment1.settings'
Starting development server at http://127.0.0.1:8000/
Quit the server with CTRL-BREAK.
[15/Dec/2017 17:23:49] "GET / HTTP/1.1" 200 14
[15/Dec/2017 17:23:50] "GET / HTTP/1.1" 200 14
[15/Dec/2017 17:24:19] "GET /admin/ HTTP/1.1" 302 0
[15/Dec/2017 17:24:19] "GET /admin/login/?next=/admin/ HTTP/1.1" 200 1650
Internal Server Error: /admin/login/
Traceback (most recent call last):
  File "C:\Python27\lib\site-packages\django\core\handlers\exception.py", line 41, in inner
    response = get_response(request)
  File "C:\Python27\lib\site-packages\django\core\handlers\base.py", line 187, in _get_response
    response = self.process_exception_by_middleware(e, request)
  File "C:\Python27\lib\site-packages\django\core\handlers\base.py", line 185, in _get_response
    response = wrapped_callback(request, *callback_args, **callback_kwargs)
  File "C:\Python27\lib\site-packages\django\views\decorators\cache.py", line 57, in _wrapped_view_func
    response = view_func(request, *args, **kwargs)
  File "C:\Python27\lib\site-packages\django\contrib\admin\sites.py", line 393, in login
    return LoginView.as_view(**defaults)(request)
  File "C:\Python27\lib\site-packages\django\views\generic\base.py", line 68, in view
    return self.dispatch(request, *args, **kwargs)
  File "C:\Python27\lib\site-packages\django\utils\decorators.py", line 67, in _wrapper
    return bound_func(*args, **kwargs)
  File "C:\Python27\lib\site-packages\django\views\decorators\debug.py", line 76, in sensitive_post_parameters_wrapper
    return view(request, *args, **kwargs)
  File "C:\Python27\lib\site-packages\django\utils\decorators.py", line 63, in bound_func
    return func.__get__(self, type(self))(*args2, **kwargs2)
  File "C:\Python27\lib\site-packages\django\utils\decorators.py", line 67, in _wrapper
    return bound_func(*args, **kwargs)
  File "C:\Python27\lib\site-packages\django\utils\decorators.py", line 149, in _wrapped_view
    response = view_func(request, *args, **kwargs)
  File "C:\Python27\lib\site-packages\django\utils\decorators.py", line 63, in bound_func
    return func.__get__(self, type(self))(*args2, **kwargs2)
  File "C:\Python27\lib\site-packages\django\utils\decorators.py", line 67, in _wrapper
    return bound_func(*args, **kwargs)
  File "C:\Python27\lib\site-packages\django\views\decorators\cache.py", line 57, in _wrapped_view_func
    response = view_func(request, *args, **kwargs)
  File "C:\Python27\lib\site-packages\django\utils\decorators.py", line 63, in bound_func
    return func.__get__(self, type(self))(*args2, **kwargs2)
  File "C:\Python27\lib\site-packages\django\contrib\auth\views.py", line 90, in dispatch
    return super(LoginView, self).dispatch(request, *args, **kwargs)
  File "C:\Python27\lib\site-packages\django\views\generic\base.py", line 88, in dispatch
    return handler(request, *args, **kwargs)
  File "C:\Python27\lib\site-packages\django\views\generic\edit.py", line 182, in post
    if form.is_valid():
  File "C:\Python27\lib\site-packages\django\forms\forms.py", line 183, in is_valid
    return self.is_bound and not self.errors
  File "C:\Python27\lib\site-packages\django\forms\forms.py", line 175, in errors
    self.full_clean()
  File "C:\Python27\lib\site-packages\django\forms\forms.py", line 385, in full_clean
    self._clean_form()
  File "C:\Python27\lib\site-packages\django\forms\forms.py", line 412, in _clean_form
    cleaned_data = self.clean()
  File "C:\Python27\lib\site-packages\django\contrib\auth\forms.py", line 187, in clean
    self.user_cache = authenticate(self.request, username=username, password=password)
  File "C:\Python27\lib\site-packages\django\contrib\auth\__init__.py", line 100, in authenticate
    user = backend.authenticate(*args, **credentials)
  File "C:\Python27\lib\site-packages\django\contrib\auth\backends.py", line 18, in authenticate
    user = UserModel._default_manager.get_by_natural_key(username)
  File "C:\Python27\lib\site-packages\django\contrib\auth\base_user.py", line 48, in get_by_natural_key
    return self.get(**{self.model.USERNAME_FIELD: username})
  File "C:\Python27\lib\site-packages\django\db\models\manager.py", line 85, in manager_method
    return getattr(self.get_queryset(), name)(*args, **kwargs)
  File "C:\Python27\lib\site-packages\django\db\models\query.py", line 373, in get
    num = len(clone)
  File "C:\Python27\lib\site-packages\django\db\models\query.py", line 232, in __len__
    self._fetch_all()
  File "C:\Python27\lib\site-packages\django\db\models\query.py", line 1102, in _fetch_all
    self._result_cache = list(self._iterable_class(self))
  File "C:\Python27\lib\site-packages\django\db\models\query.py", line 53, in __iter__
    results = compiler.execute_sql(chunked_fetch=self.chunked_fetch)
  File "C:\Python27\lib\site-packages\django\db\models\sql\compiler.py", line 876, in execute_sql
    cursor.execute(sql, params)
  File "C:\Python27\lib\site-packages\django\db\backends\utils.py", line 80, in execute
    return super(CursorDebugWrapper, self).execute(sql, params)
  File "C:\Python27\lib\site-packages\django\db\backends\utils.py", line 65, in execute
    return self.cursor.execute(sql, params)
  File "C:\Python27\lib\site-packages\django\db\utils.py", line 94, in __exit__
    six.reraise(dj_exc_type, dj_exc_value, traceback)
  File "C:\Python27\lib\site-packages\django\db\backends\utils.py", line 65, in execute
    return self.cursor.execute(sql, params)
  File "C:\Python27\lib\site-packages\django\db\backends\sqlite3\base.py", line 328, in execute
    return Database.Cursor.execute(self, query, params)
OperationalError: no such table: auth_user
[15/Dec/2017 17:24:28] "POST /admin/login/?next=/admin/ HTTP/1.1" 500 206760
Traceback (most recent call last):
  File "manage.py", line 22, in <module>
    execute_from_command_line(sys.argv)
  File "C:\Python27\lib\site-packages\django\core\management\__init__.py", line 363, in execute_from_command_line
    utility.execute()
  File "C:\Python27\lib\site-packages\django\core\management\__init__.py", line 355, in execute
    self.fetch_command(subcommand).run_from_argv(self.argv)


C:\Users\nursenakarakas\Desktop\cs361\assignment1>
C:\Users\nursenakarakas\Desktop\cs361\assignment1>python manage.py migrations
Unknown command: 'migrations'
Type 'manage.py help' for usage.

C:\Users\nursenakarakas\Desktop\cs361\assignment1>python manage.py migration
Unknown command: 'migration'
Type 'manage.py help' for usage.

C:\Users\nursenakarakas\Desktop\cs361\assignment1>python manage.py migrate
Operations to perform:
  Apply all migrations: admin, app1, auth, contenttypes, sessions
Running migrations:
  Applying contenttypes.0001_initial... OK
  Applying auth.0001_initial... OK
  Applying admin.0001_initial... OK
  Applying admin.0002_logentry_remove_auto_add... OK
  Applying app1.0001_initial... OK
  Applying contenttypes.0002_remove_content_type_name... OK
  Applying auth.0002_alter_permission_name_max_length... OK
  Applying auth.0003_alter_user_email_max_length... OK
  Applying auth.0004_alter_user_username_opts... OK
  Applying auth.0005_alter_user_last_login_null... OK
  Applying auth.0006_require_contenttypes_0002... OK
  Applying auth.0007_alter_validators_add_error_messages... OK
  Applying auth.0008_alter_user_username_max_length... OK
  Applying sessions.0001_initial... OK

C:\Users\nursenakarakas\Desktop\cs361\assignment1>python manage.py createsuperuser
Username (leave blank to use 'nursenakarakas'): admin
Email address: nursenakarakas@sts.sehir.edu.tr
Password:
Password (again):
The password is too similar to the email address.
This password is too short. It must contain at least 8 characters.
Password:
Password (again):
The password is too similar to the email address.
Password:
Operation cancelled.

C:\Users\nursenakarakas\Desktop\cs361\assignment1>python manage.py createsuperuser
Username (leave blank to use 'nursenakarakas'): admin
Email address:
Password:
Password (again):
Superuser created successfully.
