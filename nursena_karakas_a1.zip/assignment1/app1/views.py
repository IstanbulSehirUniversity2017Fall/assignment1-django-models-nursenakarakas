# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.template import loader
from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth.models import User
from .models import Car
from .models import Motor_Capacity

# Create your views here.
def save(request):
    user=User.objects.create_user('admin',email=None,password='1sehir1')
    user.first_name = admin
    user.save()
    return render(request, 'index.html',locals())
def index(request):
    return HttpResponse("<h1>Hello!<h1>")

