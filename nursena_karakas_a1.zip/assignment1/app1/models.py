# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
class Car(models.Model):
    brand=models.CharField(max_length=25)
    country=models.CharField(max_length=25)
    car_model=models.CharField(max_length=15)
    def __str__(self):
        return self.brand +"-"+ self.car_model

class Motor_Capacity(models.Model):
    car=models.ForeignKey(Car, on_delete=models.CASCADE)
    capacity=models.CharField(max_length=25)
